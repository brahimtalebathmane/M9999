import { create } from 'zustand';
import { storage } from '../src/utils/storage';
import type { User, Product, Order, Notification, Category } from '@/src/types';
import { STORAGE_KEYS } from '../src/config';
import { apiService } from '../src/services/api';
import { supabase } from '../lib/supabase-client';

interface AppState {
  user: User | null;
  token: string | null;
  isLoading: boolean;

  products: Record<string, Product[]>;
  orders: Order[];
  notifications: Notification[];
  unreadCount: number;
  categories: Category[];

  setAuth: (user: User | null, token: string | null) => void;
  setProducts: (products: Record<string, Product[]>) => void;
  setCategories: (categories: Category[]) => void;
  setOrders: (orders: Order[]) => void;
  setNotifications: (notifications: Notification[]) => void;
  setLoading: (loading: boolean) => void;

  logout: () => void;
  refreshData: () => Promise<void>;
  refreshProducts: () => Promise<boolean>;
  refreshCategories: () => Promise<boolean>;
  refreshWallet: () => Promise<void>;

  loadFromStorage: () => Promise<void>;
  saveToStorage: () => Promise<void>;
}

export const useAppStore = create<AppState>((set, get) => ({
  user: null,
  token: null,
  isLoading: true,
  products: {},
  orders: [],
  notifications: [],
  categories: [],
  unreadCount: 0,

  setAuth: (user, token) => {
    set({ user, token });
    get().saveToStorage();
  },

  refreshWallet: async () => {
    const state = get();
    if (!state.token) return;
    try {
      const response = await apiService.getMe(state.token);
      if (response.data?.user) {
        set({ user: response.data.user });
        get().saveToStorage();
      }
    } catch (error) {
      console.error('Error refreshing wallet:', error);
    }
  },

  setProducts: (products) => set({ products }),
  setCategories: (categories) => set({ categories }),
  setOrders: (orders) => set({ orders }),
  setNotifications: (notifications) => {
    const unreadCount = notifications.filter(n => !n.seen).length;
    set({ notifications, unreadCount });
  },
  setLoading: (isLoading) => set({ isLoading }),

  refreshData: async () => {
    const state = get();
    if (!state.token) return;
    try {
      const [productsResponse, categoriesResponse] = await Promise.all([
        apiService.getProducts(),
        apiService.getCategories(),
      ]);
      if (productsResponse.data) set({ products: productsResponse.data.products || {} });
      if (categoriesResponse.data) set({ categories: categoriesResponse.data.categories || [] });
    } catch (error) {
      console.error('Error refreshing data:', error);
    }
  },

  refreshProducts: async () => {
    try {
      const response = await apiService.getProducts();
      if (response.data) {
        set({ products: response.data.products || {} });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error refreshing products:', error);
      return false;
    }
  },

  refreshCategories: async () => {
    try {
      const response = await apiService.getCategories();
      if (response.data) {
        set({ categories: response.data.categories || [] });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error refreshing categories:', error);
      return false;
    }
  },

  logout: async () => {
    try {
      await storage.removeItem(STORAGE_KEYS.user);
      await storage.removeItem(STORAGE_KEYS.token);

      if (typeof window !== 'undefined') {
        localStorage.removeItem(STORAGE_KEYS.user);
        localStorage.removeItem(STORAGE_KEYS.token);
      }
    } catch (e) {
      console.error('logout error', e);
    }

    set({
      user: null,
      token: null,
      orders: [],
      notifications: [],
      products: {},
      categories: [],
      unreadCount: 0
    });
  },

  loadFromStorage: async () => {
    try {
      const [userStr, tokenStr] = await Promise.all([
        storage.getItem(STORAGE_KEYS.user),
        storage.getItem(STORAGE_KEYS.token),
      ]);
      const user = userStr ? JSON.parse(userStr) : null;
      const token = tokenStr || null;
      set({ user, token, isLoading: false });
    } catch (error) {
      console.error('Error loading from storage:', error);
      set({ isLoading: false });
    }
  },

  saveToStorage: async () => {
    try {
      const { user, token } = get();
      if (user) await storage.setItem(STORAGE_KEYS.user, JSON.stringify(user));
      if (token) await storage.setItem(STORAGE_KEYS.token, token);
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  },
}));